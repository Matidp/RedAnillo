# Laboratorio 4 - Redes y Sistemas Distribuidos


```python
import analisis as an
import matplotlib.pylab as plt
import seaborn
#plt.style.use("fivethirtyeight")
seaborn.set_style("darkgrid", {"axes.facecolor": ".90"})
```






```python
##Estos graficos los pueden ver individualmente con la funcion:
## "delay_por_conexion"
plt.style.use("bmh")
an.gdelay_equilibrio("base")
an.gdelay_prom("base")
an.gdelay_equilibrio("alter")
an.gdelay_prom("alter")
an.gdelay_equilibrio("menorcam")
an.gdelay_prom("menorcam")

```


![png](output_3_0.png)



![png](output_3_1.png)



![png](output_3_2.png)



![png](output_3_3.png)



![png](output_3_4.png)



![png](output_3_5.png)

